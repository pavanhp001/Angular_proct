import { Component } from '@angular/core';

@Component({
	selector: 'app-parent',
	templateUrl: './parent.component.html'
})
export class ParentComponent {
	public listOfCountry = [ 'Canada', 'England', 'Mexico' ];
	public selectedCountry = "";

	showSelectedCountry(country) {
		this.selectedCountry = country;
	}
} 